package com.example.jtwheadon.notetakingapp;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    final int CREATE_NOTE_REQUEST_CODE = 916;
    private List<Note> myNotes = new ArrayList<>();
    ArrayAdapter<Note> myNotesAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        GridLayout gridLayout = new GridLayout(this);
        gridLayout.setBackgroundColor(Color.WHITE);
        gridLayout.setColumnCount(1);

        Button addNoteBtn = new Button(this);
        addNoteBtn.setText(R.string.add_note_btn);
        GridLayout.LayoutParams btnLayoutParams = new GridLayout.LayoutParams();
        btnLayoutParams.width = GridLayout.LayoutParams.MATCH_PARENT;
        btnLayoutParams.height = GridLayout.LayoutParams.WRAP_CONTENT;
        addNoteBtn.setLayoutParams(btnLayoutParams);

        addNoteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, NoteActivity.class);
                startActivityForResult(intent, CREATE_NOTE_REQUEST_CODE);
            }
        });

        final ListView notesListView = new ListView(this);
        myNotesAdapter = new ArrayAdapter<Note>(this,
                android.R.layout.simple_list_item_activated_1, myNotes);
        notesListView.setAdapter(myNotesAdapter);

        GridLayout.LayoutParams notesListLayoutParams = new GridLayout.LayoutParams();
        notesListLayoutParams.width = GridLayout.LayoutParams.MATCH_PARENT;
        notesListLayoutParams.height = GridLayout.LayoutParams.WRAP_CONTENT;
        notesListView.setLayoutParams(notesListLayoutParams);

        gridLayout.addView(addNoteBtn);
        gridLayout.addView(notesListView);
        setContentView(gridLayout);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // check request code and result code
        if (requestCode == CREATE_NOTE_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            String title = data.getStringExtra("title");
            String type = data.getStringExtra("type");
            String content = data.getStringExtra("content");

            Note note = new Note(title, type, content);
            myNotes.add(note);

            myNotesAdapter.notifyDataSetChanged();
            Log.d("MainActivity", "title: " + note.getTitle() + ", type: " + type + ", content: " + content);
        }
    }
}
