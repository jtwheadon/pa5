package com.example.jtwheadon.notetakingapp;

public class Note {
    private String title;
    private String type;
    private String content;

    /**
     * Default Value Constructor that assigns default
     *  values to title, type, and content
     */
    public Note() {
        title = "BLANK TITLE";
        type = "NO TYPE";
        content = "NO CONTENT";
    }

    /**
     * Explicit Value Constructor that assigns specific
     *  values to title, type, and content
     * @param title
     * @param type
     * @param content
     */
    public Note(String title, String type, String content) {
        this.title = title;
        this.type = type;
        this.content = content;
    }

    /**
     * Returns the value of title
     * @return
     */
    public String getTitle() {
        return title;
    }

    /**
     * Returns the value of type
     * @return
     */
    public String getType() {
        return type;
    }

    /**
     * Returns the value of content
     * @return
     */
    public String getContent() {
        return content;
    }

    /**
     * Updates the value of title
     * @param title
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Updates the value of type
     * @param type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Updates the value of content
     * @param content
     */
    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return title;
    }
}
